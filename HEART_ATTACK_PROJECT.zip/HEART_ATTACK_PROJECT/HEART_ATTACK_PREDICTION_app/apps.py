from django.apps import AppConfig


class HeartAttackPredictionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'HEART_ATTACK_PREDICTION_app'
